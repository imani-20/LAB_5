package com.example.lab5_list_view_proper_;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class ChatAdapter extends BaseAdapter {

    /* Declaring variables */
    private Context context;
    private List<String> list;
    private EditText messageEditText;
    private ListView listView;

    public ChatAdapter(Context context, List<String> list, EditText messageEditText, ListView listView) {
        this.context = context;
        this.list = list;
        this.messageEditText = messageEditText;
        this.listView = listView;
    }

    @Override
    public int getCount() {
        /* This returns the rows in the listView */
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        /* This returns the data item at the specified position */
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        /* This returns the row ID of the item at the specific position */
        return position;
    }

    /* This method will be used to define the ListView's layout */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        /* 1st: See if the convertView's layout is null, you must inflate a new view */
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.layout_lab5, parent, false);
        }

        /* 2nd: Get the data item for this specific position */
        String message = (String) getItem(position);

        /* 3rd: Convert the TextView to our Layout */
        TextView messageTextView = convertView.findViewById(R.id.sendTextView);
        messageTextView.setText(message);

        /* 4th: Return the created/inflated view */
        return convertView;
    }

    /* METHOD for the notifyDataSetChange */
    public void updateData(List<String> newData) {
        list.clear();
        list.addAll(newData);
        notifyDataSetChanged();
    }

    public void setOnItemLongClickListener(AdapterView.OnItemLongClickListener listener) {
        listView.setOnItemLongClickListener(listener);
    }

    /*This method will show the AlerDialog for the deleted item*/
    private void showDeleteDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Do you want to delete this?");
        builder.setMessage("The selected row is: " + position);

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                /* Delete the item at the specified row and update the list*/
                list.remove(position);
                updateData(list);
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        /*This will show the AlerDialog*/
        builder.show();
    }
}
