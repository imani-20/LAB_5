package com.example.lab5_list_view_proper_;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button sendButton;
    private EditText editText = findViewaById(R.id.editText);

    private EditText findViewaById(int editText) {
        return null;
    }

    Message message = new Message("Hello, this is a message.", true);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_lab5);

        sendButton = findViewById(R.id.sendButton);

        sendButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {

                String messageText = editText.getText().toString();
            }
        });
    }
}