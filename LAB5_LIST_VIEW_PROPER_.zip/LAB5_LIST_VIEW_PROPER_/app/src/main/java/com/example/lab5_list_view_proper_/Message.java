package com.example.lab5_list_view_proper_;

public class Message { /*  the message class where the discussion will occur */
    private String message; /* this means the message is defined and not publicaly accessible*/
    private boolean isSend; /* this will know if the message is send or receive*/

    /*The constructor that will set up the initial messages*/
    public Message(String message, boolean isSend) {
        this.message = message;
        this.isSend= isSend;
    }

    /*The getter methods that will return what is inputed by the user*/

    public String getMessage(){
        return message;
    }

    public boolean isSend(){
        return isSend();
    }
}
